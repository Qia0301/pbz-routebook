import SwiftUI

@main
struct PBZRoutebookApp: App {
    var body: some Scene {
        WindowGroup {
            RoutebookView().ignoresSafeArea()
                .preferredColorScheme(.light)
        }
    }
}

struct RoutebookView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> RoutebookController { RoutebookController() }
    func updateUIViewController(_ controller: RoutebookController, context: Context) {}
}
