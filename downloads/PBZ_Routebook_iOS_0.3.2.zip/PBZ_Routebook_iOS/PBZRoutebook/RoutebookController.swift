import UIKit
import WebKit
import SafariServices
import UniformTypeIdentifiers

private final class WeakHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(controller, didReceive: message)
    }
}

final class RoutebookController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UIDocumentPickerDelegate {
    private var webView: WKWebView!
    private var webRoot: URL!
    private let limit = 8_000_000
    private var english = !(Locale.preferredLanguages.first ?? "en").hasPrefix("zh")

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.09, green: 0.11, blue: 0.11, alpha: 1)
        guard let root = Bundle.main.url(forResource: "Web", withExtension: nil) else {
            showError("Missing bundled guide files."); return
        }
        webRoot = root
        let controller = WKUserContentController()
        controller.add(WeakHandler(self), name: "qiaNative")
        let bridge = """
        window.QiaNative = Object.freeze({
          exportProgress: text => window.webkit.messageHandlers.qiaNative.postMessage({action:'export',text}),
          importProgress: () => window.webkit.messageHandlers.qiaNative.postMessage({action:'import'}),
          openSource: url => window.webkit.messageHandlers.qiaNative.postMessage({action:'source',url}),
          shareSupportCode: id => window.webkit.messageHandlers.qiaNative.postMessage({action:'support-image',id}),
          setLanguage: language => window.webkit.messageHandlers.qiaNative.postMessage({action:'language',language})
        });
        """
        controller.addUserScript(WKUserScript(source: bridge, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        let config = WKWebViewConfiguration()
        config.userContentController = controller
        config.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        webView.loadFileURL(root.appendingPathComponent("index.html"), allowingReadAccessTo: root)
    }

    private func isLocal(_ url: URL?) -> Bool {
        guard let url, url.isFileURL, let root = webRoot else { return false }
        return url.standardizedFileURL.path.hasPrefix(root.standardizedFileURL.path + "/")
    }

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, isLocal(message.frameInfo.request.url),
              let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        switch action {
        case "language":
            if let language = body["language"] as? String, ["zh", "en"].contains(language) { english = language == "en" }
        case "export":
            guard let text = body["text"] as? String, text.utf8.count <= limit,
                  let bytes = text.data(using: .utf8),
                  let json = try? JSONSerialization.jsonObject(with: bytes) as? [String: Any],
                  json["app"] as? String == "pbz.routebook" else { return }
            do {
                let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let file = directory.appendingPathComponent("PBZ_Routebook_Progress.json")
                try bytes.write(to: file, options: .atomic)
                let sheet = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                sheet.popoverPresentationController?.sourceView = view
                sheet.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 60, width: 1, height: 1)
                sheet.completionWithItemsHandler = { _, _, _, _ in try? FileManager.default.removeItem(at: directory) }
                present(sheet, animated: true)
            } catch { showError(english ? "Could not export this backup." : "无法导出这份备份。") }
        case "import":
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true)
            picker.delegate = self; picker.allowsMultipleSelection = false
            present(picker, animated: true)
        case "source":
            if let text = body["url"] as? String, let url = URL(string: text) { openSource(url) }
        case "support-image":
            let assets = ["wechat": "wechat.png", "alipay": "alipay.png", "cashapp": "cashapp.png", "paypal": "paypal.png"]
            guard let id = body["id"] as? String, let filename = assets[id],
                  let root = webRoot,
                  let image = UIImage(contentsOfFile: root.appendingPathComponent("images/support/" + filename).path) else { return }
            let sheet = UIActivityViewController(activityItems: [image], applicationActivities: nil)
            sheet.popoverPresentationController?.sourceView = view
            sheet.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 60, width: 1, height: 1)
            present(sheet, animated: true)
        default: break
        }
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= limit else { throw CocoaError(.fileReadTooLarge) }
            let data = try Data(contentsOf: url)
            guard data.count <= limit, let text = String(data: data, encoding: .utf8) else { throw CocoaError(.fileReadCorruptFile) }
            // Pass data as an argument, never concatenate imported text into executable JavaScript.
            webView.callAsyncJavaScript("window.App.receiveBackup(text)", arguments: ["text": text], in: nil, in: .page) { [weak self] result in
                if case .failure = result { self?.showError("Could not open the backup / 无法打开备份") }
            }
        } catch { showError(english ? "Choose a valid routebook JSON backup smaller than 8 MB." : "请选择小于 8 MB 的路书 JSON 备份。") }
    }

    private func openSource(_ url: URL) {
        guard url.scheme == "https", url.host != nil, url.user == nil, url.password == nil else { return }
        present(SFSafariViewController(url: url), animated: true)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if isLocal(navigationAction.request.url) { decisionHandler(.allow); return }
        if navigationAction.navigationType == .linkActivated, let url = navigationAction.request.url { openSource(url) }
        decisionHandler(.cancel)
    }

    private func showError(_ message: String) {
        let alert = UIAlertController(title: "PBZ Routebook", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        if isViewLoaded && view.window != nil { present(alert, animated: true) }
    }
}
